import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Genera UN solo archivo: dist/suma-a1.js (sin hash, fácil de subir por FTP)
export default defineConfig({
  plugins: [react()],
  define: { 'process.env.NODE_ENV': '"production"' },
  build: {
    lib: { entry: 'src/main.jsx', name: 'SumaA1', formats: ['iife'], fileName: () => 'suma-a1.js' },
    outDir: 'dist',
    emptyOutDir: true,
  },
});
