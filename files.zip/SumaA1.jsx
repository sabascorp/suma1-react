import { useState, useEffect, useRef } from 'react';

// ============================================================
// CONFIGURACIÓN (lo único que cambia entre Suma A1, A2, etc.)
// ============================================================
const CONFIG = {
  operation: 'suma1',
  min: 1,
  max: 9,
  duracion: 60,
  cuentaRegresiva: 5,
  niveles: [30, 60, 90],
  minutosInactividad: 3,
};
const EVENT_TYPE = 'practica';
const LAYOUT_KEY = 'sicma_layout';
const RADIO = 100;
const CIRCUNFERENCIA = 2 * Math.PI * RADIO;

const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

function clasificar(d) {
  if (d < CONFIG.niveles[0]) return 'N1';
  if (d < CONFIG.niveles[1]) return 'N2';
  if (d < CONFIG.niveles[2]) return 'N3';
  return 'N4';
}

function layoutGuardado() {
  try {
    const g = localStorage.getItem(LAYOUT_KEY);
    if (g === 'horizontal' || g === 'vertical') return g;
  } catch (e) { /* almacenamiento bloqueado */ }
  return 'vertical';
}

export default function SumaA1() {
  // Nombre que define index.php (const USER_NAME_FROM_PHP)
  const userName = (typeof USER_NAME_FROM_PHP !== 'undefined') ? USER_NAME_FROM_PHP : 'Invitado';

  // fase: 'idle' | 'countdown' | 'running' | 'done'
  const [fase, setFase] = useState('idle');
  const [layout, setLayout] = useState(layoutGuardado);
  const [segundosPrevios, setSegundosPrevios] = useState(CONFIG.cuentaRegresiva);
  const [restante, setRestante] = useState(CONFIG.duracion);
  const [nums, setNums] = useState(null); // { a, b } o null antes de empezar
  const [respuesta, setRespuesta] = useState('');
  const [correctas, setCorrectas] = useState(0);
  const [erroneas, setErroneas] = useState(0);
  const [intentos, setIntentos] = useState(0);
  const [historial, setHistorial] = useState([]);
  const [filas, setFilas] = useState([]); // tabla de resultados de la sesión
  const [errorGuardado, setErrorGuardado] = useState('');

  const inputRef = useRef(null);
  const finRef = useRef(0);
  const filaId = useRef(0);

  // Copia de lo último renderizado para que los timers lean valores actuales
  const ultimo = useRef({});
  ultimo.current = { correctas, erroneas, intentos, historial, fase };

  // ---------- Operación ----------
  const nuevaOperacion = () => setNums({ a: rand(CONFIG.min, CONFIG.max), b: rand(CONFIG.min, CONFIG.max) });

  function alternarLayout() {
    const nuevo = layout === 'horizontal' ? 'vertical' : 'horizontal';
    setLayout(nuevo);
    try { localStorage.setItem(LAYOUT_KEY, nuevo); } catch (e) { /* sin almacenamiento */ }
    if (fase === 'running') inputRef.current?.focus();
  }

  // ---------- Responder ----------
  function revisar() {
    if (fase !== 'running' || Date.now() > finRef.current || !nums) return;
    const usuario = parseFloat(respuesta);
    if (isNaN(usuario)) return;

    const correcta = nums.a + nums.b;
    const acierto = usuario === correcta;

    setIntentos(n => n + 1);
    setHistorial(h => [...h, {
      operation: `${nums.a} + ${nums.b}`,
      user: usuario,
      correct: correcta,
      status: acierto ? '✅' : '❌',
    }]);

    if (acierto) {
      setCorrectas(n => n + 1);
      nuevaOperacion();
    } else {
      setErroneas(n => n + 1);
    }
    setRespuesta('');
  }

  function onKeyDown(e) {
    if (e.repeat) return;
    if (e.key === 'Enter' || e.code === 'Space') {
      e.preventDefault();
      revisar();
    }
  }

  // ---------- Cuenta regresiva ----------
  function iniciar() {
    setSegundosPrevios(CONFIG.cuentaRegresiva);
    setFase('countdown');
  }

  useEffect(() => {
    if (fase !== 'countdown') return;
    let t = CONFIG.cuentaRegresiva;
    const id = setInterval(() => {
      t--;
      setSegundosPrevios(t);
      if (t <= 0) {
        clearInterval(id);
        empezarPractica();
      }
    }, 1000);
    return () => clearInterval(id);
  }, [fase === 'countdown']); // eslint-disable-line react-hooks/exhaustive-deps

  function empezarPractica() {
    nuevaOperacion();
    finRef.current = Date.now() + CONFIG.duracion * 1000;
    setRestante(CONFIG.duracion);
    setFase('running');
  }

  // ---------- Práctica en curso ----------
  useEffect(() => {
    if (fase !== 'running') return;
    inputRef.current?.focus();

    const id = setInterval(() => {
      const r = Math.max(0, Math.ceil((finRef.current - Date.now()) / 1000));
      setRestante(r); // React ignora el valor si no cambió
      if (r <= 0) {
        clearInterval(id);
        terminar();
      }
    }, 250);
    return () => clearInterval(id);
  }, [fase === 'running']); // eslint-disable-line react-hooks/exhaustive-deps

  function terminar() {
    setFase('done');
    const { correctas: c, erroneas: w, intentos: n, historial: h } = ultimo.current;
    const diff = c - w;
    const clasif = clasificar(diff);
    const id = ++filaId.current;

    setFilas(f => [{
      id, fecha: new Date().toLocaleString(),
      correctas: c, erroneas: w, intentos: n, diff, clasif, guardado: null,
    }, ...f]);

    guardarEnBD(id, c, w, n, clasif);

    if (typeof window.openModal === 'function') {
      window.openModal(clasif, { userName, correctCount: c, wrongCount: w, difference: diff, history: h });
    }
  }

  function guardarEnBD(id, correct, wrong, attempts, classification) {
    const marcar = (ok) => setFilas(f => f.map(x => x.id === id ? { ...x, guardado: ok } : x));
    const body = new URLSearchParams({
      correct, wrong, attempts, classification,
      operation: CONFIG.operation,
      event: EVENT_TYPE,
    });

    fetch('../config/save_results.php', { method: 'POST', body, credentials: 'same-origin' })
      .then(res => res.json().catch(() => ({})).then(data => ({ ok: res.ok, data })))
      .then(({ ok, data }) => {
        marcar(ok);
        if (!ok) setErrorGuardado(data.message || 'No se pudo guardar tu resultado.');
      })
      .catch(() => {
        marcar(false);
        setErrorGuardado('Sin conexión: tu resultado no se guardó.');
      });
  }

  // ---------- Reiniciar ----------
  function reiniciar() {
    setFase('idle');
    setNums(null);
    setRespuesta('');
    setCorrectas(0);
    setErroneas(0);
    setIntentos(0);
    setHistorial([]);
    setRestante(CONFIG.duracion);
    setErrorGuardado('');
  }

  // ---------- Cierre por inactividad ----------
  useEffect(() => {
    let tid;
    const modalVisible = () => {
      const m = document.getElementById('resultsModal');
      return !!m && getComputedStyle(m).display !== 'none';
    };
    const cerrar = () => {
      const f = ultimo.current.fase;
      if (f === 'running' || f === 'countdown' || modalVisible()) { reset(); return; }
      alert('La práctica ha finalizado por inactividad.');
      window.top.location.href = '../../practicas.php';
    };
    const reset = () => {
      clearTimeout(tid);
      tid = setTimeout(cerrar, CONFIG.minutosInactividad * 60000);
    };
    const eventos = ['mousemove', 'mousedown', 'touchstart', 'click', 'keydown'];
    eventos.forEach(ev => document.addEventListener(ev, reset, { passive: true }));
    reset();
    return () => {
      clearTimeout(tid);
      eventos.forEach(ev => document.removeEventListener(ev, reset));
    };
  }, []);

  // ---------- Valores derivados ----------
  const efectividad = intentos > 0 ? Math.ceil((correctas / intentos) * 100) : 0;
  const claseBarra = efectividad < 80 ? 'low' : efectividad < 95 ? 'medium' : 'high';

  const pct = fase === 'running' || fase === 'done' ? (restante / CONFIG.duracion) * 100 : 100;
  const claseProgreso = pct > 50 ? 'inicial' : pct > 15 ? 'medio' : 'final';

  const textoCuenta =
    fase === 'idle' ? '--'
    : fase === 'countdown' ? `${segundosPrevios} s`
    : fase === 'running' ? `${restante} s`
    : '¡Tiempo!';

  const vertical = layout === 'vertical';
  const total = filas.reduce((s, f) => s + f.diff, 0);

  return (
    <div id="practiceContainer" className="practice-main">

      <div className="main-content">

        <div className="stats-side">
          <h3>Live FeedBack</h3>
          <ul>
            <li>Puntos</li>
            <div className="stats"><span id="statsAccuracy">{correctas}/{intentos}</span></div>

            <li>Efectividad</li>
            <div className="stats"><span id="statsEffectiveness">{efectividad}%</span></div>
          </ul>
        </div>

        <div className="operation-container">
          <div
            id="operation"
            className="operation"
            style={{ cursor: 'pointer', userSelect: 'none' }}
            title="Toca para cambiar entre vertical y horizontal"
            onMouseDown={e => e.preventDefault()}
            onClick={alternarLayout}
          >
            {nums === null
              ? (vertical ? <>--<br />+ --</> : '-- + --')
              : (vertical ? <>{nums.a}<br />+ {nums.b}</> : `${nums.a} + ${nums.b}`)}
          </div>

          <svg className="progress-circle" width="230" height="230">
            <circle className="progress-background" cx="115" cy="115" r={RADIO} />
            <circle
              className={`progress-bar ${claseProgreso}`}
              cx="115" cy="115" r={RADIO}
              style={{
                strokeDasharray: `${CIRCUNFERENCIA} ${CIRCUNFERENCIA}`,
                strokeDashoffset: CIRCUNFERENCIA - (pct / 100) * CIRCUNFERENCIA,
              }}
            />
          </svg>
        </div>

      </div>

      <div className="effectiveness-bar-container">
        <div id="effectivenessBar" className={`effectiveness-fill ${claseBarra}`} style={{ width: `${efectividad}%` }} />
      </div>

      <input
        ref={inputRef}
        type="number"
        id="answer"
        className="answer"
        autoComplete="off"
        inputMode="numeric"
        disabled={fase !== 'running'}
        value={respuesta}
        onChange={e => setRespuesta(e.target.value)}
        onKeyDown={onKeyDown}
      />

      <div id="countdown" className="countdown">{textoCuenta}</div>

      <div id="buttonContainer" className="button-container">
        <button id="startButton" className="start-button" disabled={fase === 'countdown' || fase === 'running'} onClick={iniciar}>
          Iniciar
        </button>
        <button id="resetButton" className="reset-button" onClick={reiniciar}>Reiniciar</button>
      </div>

      <div id="result" className="result" style={errorGuardado ? { color: '#dc3545' } : undefined}>
        {errorGuardado}
      </div>

      <table id="leaderboard" className="leaderboard">
        <caption id="leaderboardCaption">Resultados de {userName}</caption>
        <thead>
          <tr>
            <th>Fecha</th>
            <th>Aciertos</th>
            <th>Errores</th>
            <th>Intentos</th>
            <th>Total</th>
            <th>Clasificación</th>
          </tr>
        </thead>
        <tbody id="leaderboardBody">
          {filas.map(f => (
            <tr key={f.id}>
              <td className="status-cell" style={f.guardado === null ? undefined : { color: f.guardado ? '#28a745' : '#dc3545' }}>
                {f.fecha}
              </td>
              <td>{f.correctas}</td>
              <td>{f.erroneas}</td>
              <td>{f.intentos}</td>
              <td>{f.diff}</td>
              <td>{f.clasif}</td>
            </tr>
          ))}
          {filas.length > 0 && (
            <>
              <tr className="total-row">
                <td colSpan={4} style={{ textAlign: 'right', fontWeight: 'bold' }}>Total Acumulado:</td>
                <td style={{ fontWeight: 'bold' }}>{total}</td>
                <td></td>
              </tr>
              <tr className="average-row">
                <td colSpan={4} style={{ textAlign: 'right', fontWeight: 'bold' }}>Promedio General:</td>
                <td style={{ fontWeight: 'bold' }}>{Math.round(total / filas.length)}</td>
                <td></td>
              </tr>
            </>
          )}
        </tbody>
      </table>

    </div>
  );
}
