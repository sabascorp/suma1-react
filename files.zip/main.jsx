import { createRoot } from 'react-dom/client';
import SumaA1 from './SumaA1.jsx';

createRoot(document.getElementById('suma-root')).render(<SumaA1 />);
